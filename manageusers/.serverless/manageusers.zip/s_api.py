import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='msabetta89',
    application_name='manageusers',
    app_uid='jYcWYSlbFYL2WrYQsb',
    org_uid='b7e04fc0-6661-45d9-a14e-2e213bf03a82',
    deployment_uid='5d08bad7-2068-4a03-a582-48ca437e62e5',
    service_name='manageusers',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='6.2.2',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'manageusers-dev-api', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('wsgi_handler.handler')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
